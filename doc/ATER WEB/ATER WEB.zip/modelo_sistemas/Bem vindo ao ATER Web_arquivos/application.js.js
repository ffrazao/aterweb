/**
 * Destinado � manter as configura��es personalizadas utilizadas nas p�ginas
 * deste sistema.
 */

/*
 * Fun��o para abrir janelas em popups
 */
function abrir(endereco) {
	// window.open(endereco, '_blank', 'width=1200, height=800');
	window.open(endereco, 'none', '', 'false');
	return false;
}

var relogio;
var cmin1 = 0;
var csec1 = 0;

function Minutes(data) {
	for ( var i = 0; i < data.length; i++)
		if (data.substring(i, i + 1) == ":")
			break;
	return (data.substring(0, i));
}

function Seconds(data) {
	for ( var i = 0; i < data.length; i++)
		if (data.substring(i, i + 1) == ":")
			break;
	return (data.substring(i + 1, data.length));
}

function Display(min, sec) {
	var disp;
	if (min <= 9)
		disp = " 0";
	else
		disp = " ";
	disp += min + ":";
	if (sec <= 9)
		disp += "0" + sec;
	else
		disp += sec;
	return (disp);
}

function abre_relogio() {
	csec1++;
	if (csec1 == 60) {
		csec1 = 0;
		cmin1++;
	}
	document.all["id_relogio"].innerHTML = "<font style='verdana' color='#000000' size='-1'>"
			+ Display(cmin1, csec1) + "</font>";

	relogio = setTimeout("abre_relogio()", 1000);
}